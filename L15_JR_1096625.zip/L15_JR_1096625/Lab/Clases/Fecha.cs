namespace Lab.Clases{ 

    public class Fecha
    {
        private int d;
        private int m;
        private int a;
        private int hi;
        private int hf;

        public Fecha(int day, int month, int year, int hourBegi, int hourEnd)
        {
            this.d = day;
            this.m = month;
            this.a = year;
            this.hi = hourBegi;
            this.hf = hourEnd;
        }

        public void SetD(int dia) { this.d = dia; }
        public int GetD() { return this.d; }

        public void SetM(int mes) { this.m = mes; }
        public int GetM() { return this.m; }

        public void SetA(int anio) { this.a = anio; }
        public int GetA() { return this.a; }

        public void SetHi(int horaini) { this.hi = horaini; }
        public int GetHi() { return this.hi; }

        public void SetHf(int horafin) { this.hf = horafin; }
        public int GetHf() { return this.hf; }

        public bool EsFechaValida()
        {
            if (a <= 0)
                return false;

            if (m < 1 || m > 12)
                return false;

            int maxD;
            switch (m)
            {
                case 2:
                    maxD = 28;
                    break;
                case 4:
                   maxD = 30;
                    break;   
                case 6:
                   maxD = 30;
                    break;
                case 9:
                maxD = 30;
                    break;
                case 11:
                    maxD = 30;
                    break;
                default:
                    maxD = 31;
                    break;
            }

            if (d < 1 || d > maxD)
                return false;

            if (hi < 8 || hi >= 20)
                return false;
            if (hf <= 8 || hf > 20)
                return false;

            if (hi >= hf)
                return false;

            return true;
        }
    }
}