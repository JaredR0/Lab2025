namespace Lab.Clases{ 

public class Agenda
{
    private Reserva[] resv;
    private int totResv;

    public Agenda()
    {
        resv = new Reserva[50];
        totResv = 0;
    }

    public bool AgregarResv(Reserva nueva)
    {
        for (int i = 0; i < totResv; i++)
        {
            var actual = resv[i];
            var f1 = actual.GetFec();
            var f2 = nueva.GetFec();

            if (f1.GetD() == f2.GetD() && f1.GetM() == f2.GetM() && f1.GetA() == f2.GetA())
            {
                if (f2.GetHi() < f1.GetHf() && f1.GetHi() < f2.GetHf())
                    return false;
            }
        }

        if (totResv < resv.Length)
        {
            resv[totResv] = nueva;
            totResv++;
            return true;
        }

        return false;
    }

    public void MostrarResvOrd()
    {
        for (int i = 0; i < totResv - 1; i++)
        {
            for (int j = 0; j < totResv - 1 - i; j++)
            {
                if (CompResv(resv[j], resv[j + 1]) > 0)
                {
                    var temp = resv[j];
                    resv[j] = resv[j + 1];
                    resv[j + 1] = temp;
                }
            }
        }

        for (int i = 0; i < totResv; i++)
        {
            resv[i].Mensaje();
        }
    }

    public void BuscarResp(string nombre)
    {
        for (int i = 0; i < totResv; i++)
        {
            if (resv[i].GetResp() == nombre)
            {
                resv[i].Mensaje();
            }
        }
    }

    private int CompResv(Reserva a, Reserva b)
    {
        var f1 = a.GetFec();
        var f2 = b.GetFec();

        if (f1.GetA() != f2.GetA())
            return f1.GetA() - f2.GetA();

        if (f1.GetM() != f2.GetM())
            return f1.GetM() - f2.GetM();

        if (f1.GetD() != f2.GetD())
            return f1.GetD() - f2.GetD();

        return f1.GetHi() - f2.GetHi();
    }
}
}