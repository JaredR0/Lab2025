namespace Lab.Clases{ 

    public class Reserva
    {
        private string resp;
        private Fecha fec;
        private int Ncompu;

        public Reserva(string r, Fecha f, int c)
        {
            this.resp = r;
            this.fec = f;
            this.Ncompu = c;
        }

        public void SetResp(string r) { this.resp = r; }
        public void SetFec(Fecha f) { this.fec = f; }
        public void SetNcompu(int c) { this.Ncompu = c; }

        public string GetResp() { return resp; }
        public Fecha GetFec() { return fec; }
        public int GetNcompu() { return Ncompu; }

        public bool EsCantValida()
        {
            return Ncompu >= 1 && Ncompu <= 40;
        }

        public void Mensaje()
        {
            Console.WriteLine("   Reservacion de Laboratorio    ");
            Console.WriteLine("Nombre del Responsable: " + resp);
            Console.WriteLine("Fecha a reservar: " + fec.GetD() + "/" + fec.GetM() + "/" + fec.GetA());
            Console.WriteLine("Horar de la reservacion: " + fec.GetHi() + "-" + fec.GetHf());
            Console.WriteLine("Cantidad de Computadoras a utilizar: " + Ncompu);
        }
    }
}