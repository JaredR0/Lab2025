﻿using System;
using Lab.Clases;

class MainProgram
{
    static void Main(string[] args)
    {
        Agenda ag = new Agenda();
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("    Menú de Reservas de Laboratorio    ");
            Console.WriteLine("1. Crear Reserva");
            Console.WriteLine("2. Mostrar reservas en orden");
            Console.WriteLine("3. Consultar reservas por responsable");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");

            string opc = Console.ReadLine();
            switch (opc)
            {
                case "1":
                    Console.Write("Nombre del responsable: ");
                    string resp = Console.ReadLine();
                    Console.Write("Día (1-31): ");
                    int d = int.Parse(Console.ReadLine());
                    Console.Write("Mes (1-12): ");
                    int m = int.Parse(Console.ReadLine());
                    Console.Write("Año (>0): ");
                    int a = int.Parse(Console.ReadLine());
                    Console.Write("Hora de inicio (8-19): ");
                    int hIni = int.Parse(Console.ReadLine());
                    Console.Write("Hora de fin (9-20): ");
                    int hFin = int.Parse(Console.ReadLine());

                    Fecha fec = new Fecha(d, m, a, hIni, hFin);

                    if (!fec.EsFechaValida())
                    {
                        Console.WriteLine("Fecha u horario inválido.");
                    }
                    else
                    {
                        Console.Write("Cantidad de computadoras (1-40): ");
                        int cantComp = int.Parse(Console.ReadLine());
                        Reserva resv = new Reserva(resp, fec, cantComp);

                        if (!resv.EsCantValida())
                        {
                            Console.WriteLine("Cantidad de computadoras fuera de rango.");
                        }
                        else if (!ag.AgregarResv(resv))
                        {
                            Console.WriteLine("No se pudo agregar la reserva (conflicto de horario o lleno).");
                        }
                        else
                        {
                            Console.WriteLine("Reserva agregada con éxito.");
                        }
                    }

                    Console.WriteLine("Presione una tecla para continuar...");
                    Console.ReadKey();
                    break;

                case "2":
                    Console.Clear();
                    ag.MostrarResvOrd();
                    Console.WriteLine("Presione una tecla para continuar...");
                    Console.ReadKey();
                    break;

                case "3":
                    Console.Write("Nombre del responsable a buscar: ");
                    string respBusc = Console.ReadLine();
                    Console.Clear();
                    ag.BuscarResp(respBusc);
                    Console.WriteLine("Presione una tecla para continuar...");
                    Console.ReadKey();
                    break;

                case "4":
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    Console.ReadKey();
                    break;
            }
        }
    }
}